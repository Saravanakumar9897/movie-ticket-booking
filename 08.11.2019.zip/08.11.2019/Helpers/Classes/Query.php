<?php


namespace Classes;


class Query
{

}