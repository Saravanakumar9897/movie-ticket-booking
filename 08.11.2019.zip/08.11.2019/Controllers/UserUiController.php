<?php

// Author:saravana
// Description: userinterface controllers

namespace Controllers;

use Request\Request;
use Models\Movie;

class UserUiController{

	public function dashboard(){
		// function to view the movies_running_now page
		try{

			$movies = Movie::all();
			export('backend/enduser/dashboard',$movies);

		}
		catch(Throwable $e ){
			dd($e->getMessage()."at line ".$e->getLine()."in".$e->getFile());

		}
	}
	public function movies_running_now(){
		// function to view the movies_running_now page
		try{

			$movies = Movie::all();
			export('backend/enduser/movies_running_now',$movies);

		}
		catch(Throwable $e ){
			dd($e->getMessage()."at line ".$e->getLine()."in".$e->getFile());

		}


	}
	public function tamil_movies(){


		// view('chennaiMovies.php');
		try{

			$movies = Movie::tamil();
			export('backend/enduser/movies_running_now',$movies);

		}
		catch(Throwable $e ){
			dd($e->getMessage()."at line ".$e->getLine()."in".$e->getFile());

		}
	}
	public function english_movies(){


		// view('chennaiMovies.php');
		try{

			$movies = Movie::english();
			export('backend/enduser/movies_running_now',$movies);

		}
		catch(Throwable $e ){
			dd($e->getMessage()."at line ".$e->getLine()."in".$e->getFile());

		}
	}
	public function upcoming_movies()
	{
		#code....
		try{

			$movies = Movie::all();
			export('backend/enduser/upcoming_movies',$movies);

		}
		catch(Throwable $e ){
			dd($e->getMessage()."at line ".$e->getLine()."in".$e->getFile());

		}

		// view('bigil.php');
	}
	public function movie_name()
	{
		#code....
		try{

			$movies = Movie::all();
			export('backend/enduser/movie_name',$movies);

		}
		catch(Throwable $e ){
			dd($e->getMessage()."at line ".$e->getLine()."in".$e->getFile());

		}

		// view('kaithi.php');
	}
	public function seat_numbers()
	{
		#code....
		try{

			$movies = Movie::all();
			export('backend/enduser/seat_numbers',$movies);

		}
		catch(Throwable $e ){
			dd($e->getMessage()."at line ".$e->getLine()."in".$e->getFile());

		}

		// view('kaithi.php');
	}
	public function seats_layout()
	{
		#code....
		try{

			$movies = Movie::all();
			export('backend/enduser/seats_layout',$movies);

		}
		catch(Throwable $e ){
			dd($e->getMessage()."at line ".$e->getLine()."in".$e->getFile());

		}

		// view('kaithi.php');
	}
	public function after_seat_selected()
	{
		#code....
		try{

			$movies = Movie::all();
			export('backend/enduser/after_seat_selected',$movies);

		}
		catch(Throwable $e ){
			dd($e->getMessage()."at line ".$e->getLine()."in".$e->getFile());

		}

		// view('kaithi.php');
	}
	public function seat(){
		view('backend/enduser/seat.php');
	}

}