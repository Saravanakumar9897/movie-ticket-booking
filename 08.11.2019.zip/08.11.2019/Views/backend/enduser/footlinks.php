<div class="row">
	<div class="col-md-12 text-center">
  		<hr><img src="../Assets/backend/images/logoct.png" class="text-center"><hr>
	</div>
</div>
</div>
</body>
</html>