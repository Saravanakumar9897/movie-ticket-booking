<!DOCTYPE html>
<html>
<head>
	<!-- title of the page -->
	<title>Select Seat numbers</title>
	<!-- library function including the head of the html page -->
	<link rel="stylesheet" href="../../../Assets/backend/seat_css/style.css">
	<link rel="stylesheet" href="../../../Assets/backend/seat_css/bootstrap.css">
	<link rel="stylesheet" href="../../../Assets/backend/seat_css/bootstrap.min.css">
	<link rel="stylesheet" href="../../../Assets/backend/seat_css/bootstrap-theme.min.css">
	<link rel="stylesheet" href="../../../Assets/backend/seat_css/bootstrap-theme.css">
	<script type="text/javascript" src="../../../Assets/backend/seat_js/jquery.js"></script>
	<script type="text/javascript" src="../../../Assets/backend/seat_js/bootstrap.js"></script>
	<script type="text/javascript" src="../../../Assets/backend/seat_js/bootstrap.min.js"></script>
</head>
<body>
	<!-- main container start -->
	<div class="container text-center">
		<br><br><br><br>
		<!-- form container start -->
		<form action="/seats_layout">
			<!-- Using the select box to getting the input of the total number of the seat will been booking by the user -->
			<label>Enter the number of seats:</label>
			<!-- select box -->
			<select class="select-drop" onchange="seatview(this.value)">
				<option value="1">Select</option>
				<option value="1">1</option>
				<option value="2">2</option>
				<option value="3">3</option>
				<option value="4">4</option>			
				<option value="5">5</option>			
				<option value="6">6</option>			
				<option value="7">7</option>			
				<option value="8">8</option>			
				<option value="9">9</option>			
			</select>
			<!-- select box end -->
			<input type="submit" class="btn btn-success" name="submission">
		</form>
		<!-- form container end -->
	</div>
<!-- script container -->
	<script type="text/javascript">
		// #javascript.function(select box selected) This below function using to storing the number of seats selected by the user in the input storage by using localStorage.settime;
		var movie_name = localStorage.setitem;
		function seatview(numbers) {	
			alert('You are selected '+numbers+' seats.');
			total_seats = numbers;
			localStorage.setItem('totalSeats', total_seats);
			//storing into the as internal storsge file
		}
		// #javascript.function(select box selected) end
	</script>
<!-- script container end -->
</body>
</html>