<!DOCTYPE html>
<html>
<head>
	<!-- Title of the page -->
	<title>Movie Ticket Booking System</title>
	<!-- Including the library files. -->
	<link rel="stylesheet" href="../../../Assets/backend/seat_css/style.css">
	<link rel="stylesheet" href="../../../Assets/backend/seat_css/bootstrap.css">
	<link rel="stylesheet" href="../../../Assets/backend/seat_css/bootstrap.min.css">
	<link rel="stylesheet" href="../../../Assets/backend/seat_css/bootstrap-theme.min.css">
	<link rel="stylesheet" href="../../../Assets/backend/seat_css/bootstrap-theme.css">
	<script type="text/javascript" src="../../../Assets/backend/seat_js/jquery.js"></script>
	<script type="text/javascript" src="../../../Assets/backend/seat_js/bootstrap.js"></script>
	<script type="text/javascript" src="../../../Assets/backend/seat_css/bootstrap.min.js"></script>
</head>
<body>	
	<!-- main container start -->
	<div class="container text-center"><br>
		<!-- screen container -->
		<div class="screen text-center">Eye to View</div><br><br>
		<!-- This below php function is used to printing number of rows and columns by using the for condition -->
		<?php for($row=1;$row<=8;$row++){
		// This if function is printing the Class Name 
			if($row==1){ ?>
			<h5 class="text-center">General Class</h5>
		<?php }if($row == 5){ ?>
			<h5 class="text-center">Second Class</h5>
		<?php }elseif($row == 7){ ?>
			<h5 class="text-center">First Class</h5>
		<?php }
		// This if(class name printing) end
		// The below if condition is setting seat group name in each row has unique seat group name
		 if($row==1){$seat_group='A';}else{$seat_group++;}
		// This if(seat group name assign) end
		// The below for loop will is using to print how many seats in the each row
		  for($col=1;$col<=20;$col++){ ?>
			<span id="<?php echo $seat_group.$col; ?>" onclick="seatview(this.id)" class="btn btn-default btn-xs"></span>

		<?php 
		// The below if condition is providing gap between the particular (in this loop provide gap between 5th and 6th seat)
		if($col==5){echo"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";}
		// The below if condition is providing gap between the particular (in this loop provide gap between 15th and 16th seat)
		if($col==15){echo"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";} 
		// provide gap between the each seats
		echo"&nbsp;&nbsp;&nbsp;"; } ?>
		<!-- prvide gap between the two rows -->
				<br><br>
		<?php }
		// This is end of row loop
		?>
	</div>
	<!-- seat-preview container -->
	<h5 class="text-center selected-seats">Selected Tickets</h5>
	<div class="text-center">
		<label class="text-center" id="showSelectSeat" readonly="true">Please Select Seats...</label>
	</div><br>
	<!-- check box for user agreementation -->
	<div class="text-center">
		<input type="checkbox" id="confirm" name="confirmation" value="confirm">Confirm Booking<br>
	</div><br>
	<div class="text-center">
	<!-- submit button -->
		<button id="submit" onclick="submit()">submit</button>
	</div>
<!-- script container -->
<script type="text/javascript">
	//variavle defining
	var check = 0;
	var select_seats = [];
	var total_seat = localStorage.getItem('totalSeats');
	// getting the total no of seat usinf localstorage.setitem
	// This below function trigerred when the seat is selected at each and every seat is to be triger this function
	function seatview(seat_no) {
		// Each and every time this function call the previous array is cleared
		select_seats = [];
		// This below condition is finding the numbers of seat from the seat number(example seat number=A12)
		if(seat_no.length == 2){//This condition is working when the length of seat_no(A12 == 2)
			seat_number = seat_no[1];
			seat_number=Number(seat_number);
		}else{//This is the else part of the if condition
			seat_number = seat_no[1]+seat_no[2];
			seat_number=Number(seat_number);
		}
		if(total_seat >= 2){//This function trigerred by when the total seat selected is greater or equal to 2
		select_seats[0] = seat_no;//first seat stored in select_seats[0] array
			for (var i = 1; i < total_seat; i++) {//This the loop for automatically select the next seats When the total seat achieved
				if((seat_no[0]=='H')&&(seat_number == 20)){//This is the condition when the total seat is greater than 1 and selected seat is h20,We does not allowed to select that seat
					alert('Plaese check your seat selection');
					exit();//exit the script function
				}else{
					if(seat_number == 20){ 
						seat_number=0; 
					}else{
					select_seats[i] = seat_no[0]+(seat_number+1);
					seat_number++;
					document.getElementById("showSelectSeat").innerHTML = select_seats;
					$(document).ready(function(){
					  $("span").click(function(){
					    $(this).nextAll("span").andSelf().slice(0,total_seat).addClass("after-seat-select");
					  });
					});
					}
				}
			}
		}else{//This function else part of the if condition if(total_seat >= 2)
			select_seats[0] = seat_no;
			document.getElementById("showSelectSeat").innerHTML = select_seats;
			$(document).ready(function(){
				$("span").click(function(){
				$(this).addClass("after-seat-select");
				});
			});}
		check = 0;
	}
	function submit(){//This loop will run when the submit button is trigerred and validate the values
		if(total_seat == select_seats.length){
			if(document.getElementById("showSelectSeat").value == 'Please Select Seats...'){
				alert('good');
			}
			if(document.getElementById("confirm").checked == true){		
				localStorage.setitem = select_seats;
				location.href=('/after_seat_selected?submission=Submit');
			}else{
				alert('please confirm the checkbox');
			}
		}else{
			alert('please select '+total_seat+' seats.');
		}
	}
	$(document).ready(function(){
		$("span").click(function(){
			$("span").click("span").removeClass("after-seat-select");
		});
	});
</script>
<!-- script container end -->
</body>
</html>