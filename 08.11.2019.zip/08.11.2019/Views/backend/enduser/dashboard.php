<!-- Author: Saravana kumar
Description: Dashboard for the User
 -->
 <?php $movies = import();?>
<!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
	<title>Movie Ticket Booking System</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="../../../Assets/backend/css/style.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
</head>
<body>
	<div class="container-fluid">
		<div class="row head_logo">
			<div class="col-md-4 text-left">
				<a href=""><img src="../Assets/backend/images/logoct.png" class="logo_head"></a>
			</div>
			<div class="col-md-4 input-group text-left">
				<input type="text" placeholder="Search Here...." class="search-bar rounded">
				<div class="input-group-append">
					<button class="btn btn-secondary" type="button">
						<i class="glyphicon glyphicon-search">Search</i>
					</button>
				</div>				
			</div>
			<div class="col-md-2">
			</div>
			<div class="col-md-2 text-center">
				<?php if($_SESSION['user']['role_name']=='customer'){?>
				<a href="/admin"><input type="Button" class="btn btn-log-in" value="Sign-Out"></a>
				<?php }else{ ?>
					<a href="/admin"><input type="Button" class="btn btn-log-in" value="Log-In/Sign-Up"></a>
				<?php } ?>
			</div>
		</div>
		<div class="row">
			<!-- Navigation -->
			<nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top justify-content-center nav-center">
			  <ul class="navbar-nav">
			  	<li class="nav-item" id="Dropdown-location" >
					 <div class="dropdown">
					  <button type="button" class="btn btn-drop dropdown-toggle" data-toggle="dropdown">
					    Location
					  </button>
					  <div class="dropdown-menu">
					    <a class="dropdown-item " id="chennai" onclick="changeActiveChennai()" href="#">Chennai</a>
					    <a class="dropdown-item" id="Kancheepuram" onclick="changeActiveKancheepuram()" href="#" >Kancheepuram</a>
					    <a class="dropdown-item" id="vellore" onclick="changeActiveVellore()" href="#">Vellore</a>
					  </div>
					</div> 
			  	</li>
			  	<li class="nav-item" id="Dropdown-languages" >
					 <div class="dropdown">
					  <button type="button" class="btn btn-drop dropdown-toggle" data-toggle="dropdown">
					    Languages
					  </button>
					  <div class="dropdown-menu">
					    <a class="dropdown-item " id="tamil" onclick="changeActiveTamil()" href="#">Tamil</a>
					    <a class="dropdown-item" id="english" onclick="changeActiveEnglish()" href="#">English</a>
					    <a class="dropdown-item" id="hindi" onclick="changeActiveHindi()" href="#">Hindi</a>
					  </div>
					</div> 
			  	</li>
			  </ul>
			</nav>		
		</div>
		<div class="row" id="carousel-1">
			<div id="carousel-1">
				<div id="demo" class="carousel slide " data-ride="carousel">
				  <!-- Indicators -->
				  <ul class="carousel-indicators ">
				    <li data-target="#demo" data-slide-to="0" class="active"></li>
				    <li data-target="#demo" data-slide-to="1"></li>
				    <li data-target="#demo" data-slide-to="2"></li>
				  </ul>
				  <!-- The slideshow -->
				  <div class="carousel-inner">
				    <div class="carousel-item active">
				      <a href="/movie_name?<?php echo $movies[3][2];?>"><img class="img-responsive" src="<?php echo $movies[3][11];?>" alt="Los Angeles" width="1400" height="400"></a>
				    </div>
				    <div class="carousel-item">
				      <a href="/movie_name?<?php echo $movies[11][2];?>"><img src="<?php echo $movies[11][11];?>" alt="Chicago" width="1400" height="400"></a>
				    </div>
				    <div class="carousel-item">
				      <a href="/movie_name?<?php echo $movies[4][2];?>"><img src="<?php echo $movies[4][11];?>" alt="New York" width="1400" height="400"></a>
				    </div>
				  </div>
				  <!-- Left and right controls -->
				  <a class="carousel-control-prev" href="#demo" data-slide="prev">
				    <span class="carousel-control-prev-icon"></span>
				  </a>
				  <a class="carousel-control-next" href="#demo" data-slide="next">
				    <span class="carousel-control-next-icon"></span>
				  </a>
				</div>
			</div>
		</div>
		<div class="row container-fluid text-center">
			<ul class="nav nav-pills center-pills nav-justified nav-center">
				<li class="nav-item " >
			      <a class="navbar-brand" href="" id="Nav-value" onclick=" ">SELECT YOUR MOVIE</a>
			    </li>
			    <li class="nav-item " >
			      <a class="nav-link	" href="#" id="MoviesRunnigNow" onclick="changeActiveMRN()">Movies Running NOW</a>
			    </li>
			    <li class="nav-item"  >
			      <a class="nav-link" id="UpcomingMovies" href="#"onclick="changeActiveUM()">UPCOMING MOVIES</a>
			    </li>
			</ul>
		</div>
		<div class="row" id="box-1">	
			<div class="col-md-2">
				<table cellpadding="0px" cellspacing="5px">
					<tr><td><input type="checkbox"></td><td><p>Tamil</p></td></tr>
					<tr><td><input type="checkbox"></td><td><p>English</p></td></tr>
					<tr><td><input type="checkbox"></td><td><p>Hindi</p></td></tr>
					<tr><td><input type="checkbox"></td><td><p>Malayalam</p></td></tr>
					<tr><td><input type="checkbox"></td><td><p>Kannada</p></td></tr>
				</table>
			</div>
			<div class="col-md-10" id="mrn">
				<?php for($i=12;$i>=1;$i-=3) { ?>
							<div class="row">
								<?php for($j=$i;$j>=$i-2;$j-=1) { ?>
									<div class="col-md-4 movie-box">
										<a href="/movie_name?<?php echo strtolower($movies[$j][2])?>">
										<img src="<?php echo $movies[$j][10]?>" class="box-image">
										<h3 class="text-left"><b><?php echo $movies[$j][2]?></b></h3>
										<h6 class="text-left">Action</h6>
										</a>
									</div>
								<?php } ?>
							</div>
				<?php } ?>
			</div>
		</div>
	</div>
	<br>
	<br>
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<script>
		function changeActiveChennai(){
			document.getElementById('chennai').classList.add('active');
			document.getElementById('Kancheepuram').classList.remove('active');
			document.getElementById('vellore').classList.remove('active');
		}
		function changeActiveKancheepuram(){
			document.getElementById('chennai').classList.remove('active');	
			document.getElementById('Kancheepuram').classList.add('active');	
			document.getElementById('vellore').classList.remove('active');			
		}
		function changeActiveVellore(){
			document.getElementById('vellore').classList.add('active');
			document.getElementById('chennai').classList.remove('active');
			document.getElementById('Kancheepuram').classList.remove('active');
		}
		function changeActiveTamil(){
			document.getElementById('tamil').classList.add('active');
			document.getElementById('english').classList.remove('active');
			document.getElementById('hindi').classList.remove('active');
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){
					var a = this.responseText;
					console.log(a);
					document.getElementById('mrn').innerHTML=a;
				}
			};
			xhttp.open("get","/tamil_movies",true);
			xhttp.send();
		}
		function changeActiveEnglish(){
			document.getElementById('tamil').classList.remove('active');	
			document.getElementById('english').classList.add('active');	
			document.getElementById('hindi').classList.remove('active');
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){
					var a = this.responseText;
					console.log(a);
					document.getElementById('mrn').innerHTML=a;
				}
			};
			xhttp.open("get","/english_movies",true);
			xhttp.send();			
		}
		function changeActiveHindi(){
			document.getElementById('hindi').classList.add('active');
			document.getElementById('tamil').classList.remove('active');
			document.getElementById('english').classList.remove('active');
		}
		function changeActiveMRN(){
			document.getElementById('MoviesRunnigNow').classList.add('active');
			document.getElementById('UpcomingMovies').classList.remove('active');
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){
					var a = this.responseText;
					console.log(a);
					document.getElementById('mrn').innerHTML=a;
					document.getElementById('Nav-value').innerHTML="MOVIES RUNNING NOW";

				}
			};
			xhttp.open("get","/movies_running_now",true);
			xhttp.send();	
		}
		function changeActiveUM(){
			document.getElementById('UpcomingMovies').classList.add('active');
			document.getElementById('MoviesRunnigNow').classList.remove('active');
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){
					var a = this.responseText;
					console.log(a);
					document.getElementById('mrn').innerHTML=a;
					document.getElementById('Nav-value').innerHTML="UPCOMING MOVIES TO SHOW";
				}
			};
			xhttp.open("get","/upcoming_movies",true);
			xhttp.send();	
		}
	</script>
<div class="row text-center">
<hr class="hr">
<span>
<img src="../Assets/backend/images/logoct.png" class="text-left">
<span class="text-right"> <p>Copyright 2019 © Infiniti Entertainment Pvt,Ltd.</p></span>
</span>
<hr>
</div>
</body>
</html>